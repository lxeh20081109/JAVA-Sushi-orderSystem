/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desing;
import java.util.*;
/**
 *
 * @author 17jz0143
 */
public class calander {
    public static void main (String[] args) {
  int years,months,day_1,day_2,sum_1,sum_2,sum,firstDay;
  boolean testYear;
  System.out.print("\n");
  System.out.print("*********欢迎使用万年历查询时间*********");
  System.out.println ("\n");
  System.out.print("请输入年份：");
  Scanner input=new Scanner(System.in);
  years=input.nextInt();
  day_1=0;
  day_2=0;
  sum_1=0;
  sum_2=0;
  sum=0;
  firstDay=0;
  if((years%4==0&&years%100!=0)||years%400==0)
  {
  System.out.println ("\t"+years+"是闰年");
  testYear=true;
  }
  else{
  System.out.println ("\t"+years+"是平年");
  testYear=false;
  }
  for(int i=1900;i<years;i++)
  {
  if((i%4==0&&i%100!=0)||i%400==0)
  {
  day_1=366;
  }
  else
  {
  day_1=365;
  }
  sum_1=sum_1+day_1; //计算从输入年份1月1号到1900年1月1号总天数
  }
  System.out.println ();
  System.out.print("请输入月份：");
  months=input.nextInt();
  /*
  *计算输入的月份到该年份的天数
  */
  for(int j=1;j<months;j++)
  {
  if(j==2)
  {
  if(testYear=true)
  {
  sum_2=29+sum_2;
  }
  else{
  sum_2=28+sum_2;
  }
  }
  else if((j==4)||(j==6)||(j==9)||(j==11))
  {
  sum_2=30+sum_2;
  }
  else
  {
  sum_2=31+sum_2;
  }
  }
  if(months==2)
  {
  if(testYear)
  {
  day_2=29;
  }
  else
  {
  day_2=28;
  }
  }
  else if((months==4)||(months==6)||(months==9)||(months==11))
  {
  day_2=30;
  }
  else
  {
  day_2=31;
  }
  sum=sum_1+sum_2; //累加记录距离1900年1月1号的天数
  System.out.print("\n\n");
  System.out.println ("星期天"+"\t星期一"+"\t星期二"+"\t星期三"+"\t星期四"+
  "\t星期五"+"\t星期六"+"\n");
  int temp=1+sum%7; //计算该月份的第一天是星期几
  /**周一-周六：使用数字1-6表示，周日用0表示*/
  if(temp==7)
  {
  firstDay=0;
  }
  else{
  firstDay=temp;
  }
  for(int nullNo=0;nullNo<firstDay;nullNo++)
  {
  System.out.print("\t"); //循环输出第一行的空格
  }
  for(int x=1;x<=day_2;x++)
  {
  System.out.print(x+"\t");
  if((sum+x-1)%7==5)
  {
  System.out.print("\n");//判断当前日x是否是周六，如果是，换行
  }
  }
  }
}




