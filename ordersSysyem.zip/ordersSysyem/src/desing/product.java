/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desing;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class product {
        private String number;
        private String name;
        private Integer price;
    //    private Integer quantity;
        
        
        public product(String number,String name,Integer price){
            this.number = number;
            this.name = name;
            this.price = price;
        //    this.quantity = quantity;
        }
        public product(){
            this("","",0);
        }
        public void print(){
            System.out.print(toString());
        }
        public void println(){
            print();
            System.out.println();
        }
        public String toString(){
            return "商品番号 :" + getnumber() + "\n   "  + "商品名前 :" +getname() + "\n   " + "単価    :" +getprice() + "\n" + "=================================================";
        }
        public String getnumber(){
            return number;
        }
        public String getname(){
            return name;
        }
        public Integer getprice(){
            return price;
        }
     //   public Integer getquantity(){
      //      return quantity;
      //  }
        public void setnumber(String number){
            this.number = number;
        }
        public void setname(String name){
            this.name = name;
        }
        public void setprice(Integer price){
            this.price = price;
        }
     //   public void setquantity(Integer quantity){
     //       this.quantity = quantity;
     //   }_
        public static void main(String[] args){
            List<product> products = new ArrayList<>();
            products.add(new product("549","彩　1~５人前",1200));
            
            for(product pr: products){
                System.out.println(pr);
            }
        }
}
