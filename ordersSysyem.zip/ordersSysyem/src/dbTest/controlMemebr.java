/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.coustomerID;
import desing.coustomerIDChange;
import desing.coustomerNameChange;
import desing.coustomerentry;
import desing.orderDetailBoundary;
import desing.orderdate;
import java.sql.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class controlMemebr {
    private MemberDAO memberDAO;
    private coustomerentry centry;
    private orderdate odate;
    private Integer parseInt;
    private coustomerIDChange cIDChange;
    private   coustomerNameChange cNameChange;
    private String text;
    private coustomerID coustomid;
    private orderDetailBoundary orderdeta;
    private Integer id;
    private String name;
/*    private Integer id;
    private String name;
    private String tele;
    private String address;
    private String entryDate;
  */  
    
    public controlMemebr(){
        memberDAO = new MemberDAO();
 //       odate = new orderdate();
        centry = new coustomerentry();
        cIDChange = new coustomerIDChange();
        cNameChange = new  coustomerNameChange();
        
        
    }
    
    public void insertMember(Integer id,String name,String tele,String address,String entryDate){

        try{

            Member member = new Member(id,name,tele,address, Date.valueOf(entryDate));
            if(memberDAO.dbInsertMember(member) > 0){
                centry.showInfomationMessage("登録しました");
                centry.initTextFieldAll();
            }
            else{
                centry.showErrMessage("IDが登録済みです");
                centry.selectTextFieldID();
            }
            

        }
        catch (NumberFormatException e) {
            odate.showErrMessage("IDは数値で入力してください");
            centry.selectTextFieldID();
        }
        catch (IllegalArgumentException e) {
             odate.showErrMessage("日付の書式が違います。YYYY-MM-DD形式で入力してください");                 // 日付のフォーマットエラーを表示
        }
    }

    public void toId(int parseInt) {
        this.parseInt = parseInt;
        cIDChange.toID(parseInt);
    }
    public int getId(){
        return parseInt;
    }

    public void showIdChange() {
        cIDChange.setVisible(true);
    }

    public void toName(String text) {
        this.text = text;
         cNameChange.toName(text);
    }

    public void showNameChange() {
        cNameChange.setVisible(true);
    }

    public void showDetaliBpundy() {
        orderdeta.setVisible(true);
    }

    public void toorderHistoryId(int parseInt) {
        
    }

    public void showAll() {
        coustomerID coustomid = new coustomerID();
        coustomid.setVisible(true);
    }

    public void toorderHistoryId(Integer id, String name) {
        this.id = id;
        this.name = name;
        System.out.print("中间");
        orderdeta.give(id,name);
    }
    
}
