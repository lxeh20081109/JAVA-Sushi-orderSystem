/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLDataException;
import java.sql.SQLIntegrityConstraintViolationException;

/**
 *
 * @author user
 */
public class MemberDAO {
    private static Connection  con;
    
    private  static PreparedStatement ps;
    
    public MemberDAO(){
        DBManager dbManager = DBManager.getDBManager();
        con                = dbManager.getConnection();
    }
    
    public List<Member>selectMemberExecute(){
        List<Member>memberList = new ArrayList();
        try{
            memberList.clear();
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Member member = new Member();
                setMember(member,rs);
                memberList.add(member);
            }
            rs.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return memberList;
    }
    /*
    public List<Member>selectmemberExcute(){
    List<Member>memberList = new ArrayList();
    try{
        memberList.clear();
    Resultset rs = ps.executeQuery();
    while(rs.next()){
        Member member = new Member();
    
        setMember(member,rs);
        memberList.add
    
    
    
    */
    public void setMember(Member member,ResultSet rs){
        try{
            Integer id = rs.getInt("ID");
            String name = rs.getString("NAME");
            String tele = rs.getString("TELE");
            String address = rs.getString("ADDRESS");          
            Date entryDate = rs.getDate("ENTRY_DATE");
            member.setId(id);
            member.setName(name);
            member.setEntryDate(entryDate);
            member.setaddress(address);
            member.settele(tele);
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    public int dbInsertMember(Member member){
        String sql ="INSERT INTO MEMBER " +
                " values(?, ?, ?, ?, ?) ";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, member.getId());
            ps.setString(2, member.getName());          
            ps.setString(3, member.gettele());
            ps.setString(4, member.getaddress());
            ps.setDate(5, member.getentryDate());
            
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;   // 挿入できなかったので挿入件数0を返す
        }
        catch (SQLException e) {    
           e.printStackTrace();
           return -1;
        }
    }
    public int dbUpdateMemberEntryDate(int id, Date entryDate){
        String sql ="UPDATE MEMBER " +
                " SET ENTRY_DATE = ? " +
                " WHERE ID = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setDate(1, entryDate);
            ps.setInt(2, id);

            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
    public int dbUpdateMemberName(int id, String name){
        String sql ="UPDATE MEMBER " +
                " SET NAME = ? " +
                " WHERE ID = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, id);
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
    public int dbUpdateMemberAddress(int id, String address){
        String sql ="UPDATE MEMBER " +
                " SET ADDRESS = ? " +
                " WHERE ID = ? ";
        try{
            ps = con.prepareStatement(sql);
                        
            ps.setString(1, address);
            ps.setInt(2, id);           
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
    public int dbUpdateMemberTele(int id, String tele){
        String sql ="UPDATE MEMBER " +
                " SET TELE = ? " +
                " WHERE ID = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, tele);
            ps.setInt(2, id);
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
    
    public int dbDeleteMemberId(int id) {
        String sql = "DELETE FROM MEMBER " +
                     " WHERE ID = ? ";
        try {
            ps = con.prepareStatement(sql);         // SQLを実行するためのステートメント作成
            ps.setInt(1, id);           // 1つ目のパラメータへの値設定
            return ps.executeUpdate();              // SQLの実行
        }
        catch (SQLException e) {    
           e.printStackTrace();
           return -1;
        }        
    }
    public int dbDeleteMemberName(String name) {
        String sql = "DELETE FROM MEMBER " +
                     " WHERE NAME = ? ";
        try {
            ps = con.prepareStatement(sql);         // SQLを実行するためのステートメント作成
            ps.setString(1, name);           // 1つ目のパラメータへの値設定
            return ps.executeUpdate();              // SQLの実行
        }
        catch (SQLException e) {    
           e.printStackTrace();
           return -1;
        }        
    }  
        public  List<Member> dbSearchMemberId(int id) {
        List<Member> memberList = new ArrayList<>();    
        String sql = "SELECT * " +              // ID指定検索用SQL
                     " FROM  MEMBER " + 
                     " WHERE ID = ? ";          // パラメータとなる項目は？を指定する
        try {
            ps = con.prepareStatement(sql);     // SQLを実行するためのステートメント作成
            ps.setInt(1, id);                   // ？としていたパラメータに値を設定 1つ目の?にidの値をint型として設定
            memberList = selectMemberExecute(); // SQLの実行
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return memberList;
    } 
    public List<Member>dbSearchMemberAll(){
        List<Member>memberList = new ArrayList<>();
        String sql ="SELECT *" + 
                "FROM MEMBER ";
        try{
            ps = con.prepareStatement(sql);
            memberList = selectMemberExecute();
        }        
        catch(SQLException e){
            e.printStackTrace();
        }
        return memberList;
    }
    public int dbUpdateMemberNameTel(String name, String tele){
        String sql ="UPDATE MEMBER " +
                " SET TELE = ? " +
                " WHERE NAME = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, tele);
            ps.setString(2, name);
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
        public int dbUpdateMemberNameAddress(String name, String address){
        String sql ="UPDATE MEMBER " +
                " SET ADDRESS = ? " +
                " WHERE NAME = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, address);
            ps.setString(2, name);
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
          
        public int dbUpdateMemberNameDate(String name, Date entrydate){
        String sql ="UPDATE MEMBER " +
                " SET ENTRY_DATE = ? " +
                " WHERE NAME = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setDate(1, entrydate);
            ps.setString(2, name);
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
    public  List<Member> dbSearchMemberNameLike(String name) {
        List<Member> memberList = new ArrayList<>();    
        String sql = "SELECT * " +              // NAME指定検索用SQL
                     " FROM  MEMBER " + 
                     " WHERE NAME LIKE ? ";          // パラメータとなる項目は？を指定する
        try {
            ps = con.prepareStatement(sql);     // SQLを実行するためのステートメント作成
            ps.setString(1, "%" + name + "%");                   // ？としていたパラメータに値を設定 1つ目の?にidの値をint型として設定
            memberList = selectMemberExecute(); // SQLの実行
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return memberList;
    }
    public static void main(String[] args){
        MemberDAO memberDAO = new MemberDAO();
        List<Member>memberList = new ArrayList();
        Member newMember = new Member(10,"ss","1212","sss",Date.valueOf("2018-11-11"));
        int count = memberDAO.dbInsertMember(newMember);
        System.out.println(count);
        memberList = memberDAO.dbSearchMemberAll();
        for(Member member : memberList){
            member.print();
        }
        
        
        

        count = memberDAO.dbDeleteMemberId(10);
        System.out.println("削除件数 = " + count);
        memberList = memberDAO.dbSearchMemberAll();
        System.out.println("件数 = " + memberList.size());
        for (Member member : memberList) {
            member.println();
        }
    }
}


