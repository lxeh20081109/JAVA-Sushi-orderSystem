/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.product;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 17jz0143
 */
public class order {
        private String number;
        private String name;
        private Integer price;
        private Integer list;
        private Integer count;
       
        
        public order(String number,String name,Integer price,Integer list,Integer count){
            this.number = number;
            this.name = name;
            this.price = price;
            this.list = list;
            this.count = count;
        }
        public order(){
            this("","",0,0,0);
        }
        public void print(){
            System.out.print(toString());
        }
        public void println(){
            print();
            System.out.println();
        }
        public String toString(){
            return number + "," + name + "," + price + "," + list + "," + count;
        }
        public Integer getcount(){
            return count;
        }
        public String getnumber(){
            return number;
        }
        public String getname(){
            return name;
        }
        public Integer getprice(){
            return price;
        }
        public Integer getlist(){
            return list;
        }
     //   public Integer getquantity(){
      //      return quantity;
      //  }
        public void setcount(Integer count){
            this.count = count;
        }
        public void setnumber(String number){
            this.number = number;
        }
        public void setname(String name){
            this.name = name;
        }
        public void setprice(Integer price){
            this.price = price;
        }
        public void setlist(Integer list){
            this.list = list;
        }
        public static void main(String[] args){
            List<order> prod = new ArrayList<>();
            prod.add(new order("549","彩　1~５人前",1200,12,1200 * 12 ));

            for(order pr: prod){
                System.out.println(pr);
            }
        }
}
