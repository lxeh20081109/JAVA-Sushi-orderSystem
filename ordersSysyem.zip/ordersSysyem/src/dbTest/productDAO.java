/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;
import desing.product;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
/**
 *
 * @author user
 */
public class productDAO {
    private static Connection  con;
    
    private  static PreparedStatement ps;
    
    public productDAO(){
        DBManager dbManager = DBManager.getDBManager();
        con                = dbManager.getConnection();
    }
    public List<product> selectproductExecute(){
        List<product>productList = new ArrayList<>();
        try{
            productList.clear();
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                product products = new product();
                setproduct(products,rs);
                productList.add(products);
            }
            rs.close();
            
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return productList;
    } 
    
    public void setproduct(product products,ResultSet rs){
        try{
            String number = rs.getString("NUMBER");
            String name = rs.getString("NAME");
            Integer price = rs.getInt("PRICE");
            products.setnumber(number);
            products.setname(name);
            products.setprice(price);
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    public List<product> dbSearchproductAll(){
        List<product> productList = new ArrayList<>();
        String sql = "SELECT *" +
                "FROM PRODUCT ";
        try{
            ps = con.prepareStatement(sql);
            productList = selectproductExecute();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return productList;
    }
    public int dbInsertproduct(product prod){
        String sql = "INSERT INTO PRODUCT " +
                " values(?,?,?) ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1,prod.getnumber());
            ps.setString(2,prod.getname());
            ps.setInt(3, prod.getprice());
            
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;   // 挿入できなかったので挿入件数0を返す
        }
        catch (SQLException e) {    
           e.printStackTrace();
           return -1;
        } 
    }
    public int dbDeleteProduct(String name){
        String sql = "DELETE FROM PRODUCT " +
                " WHERE NUMBER = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            return ps.executeUpdate();
        }
                catch (SQLException e) {    
           e.printStackTrace();
           return -1;
        }  
    }
    public  List<product> dbSearchproductNumber(String number){
        List<product>pro = new ArrayList<>();
        String sql = "SELECT *" +
                " FROM PRODUCT " +
                " WHERE NUMBER = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, number);
            pro = selectproductExecute();
        }        catch (SQLException e) {
            e.printStackTrace();
        }
        return  pro;
    }
    public  List<product> dbSearchProductNameLike(String name) {
        List<product>productList = new ArrayList<>();    
        String sql = "SELECT * " +              // NAME指定検索用SQL
                     " FROM  PRODUCT " + 
                     " WHERE NAME LIKE ? ";          // パラメータとなる項目は？を指定する
        try {
            ps = con.prepareStatement(sql);     // SQLを実行するためのステートメント作成
            ps.setString(1, "%" + name + "%");                   // ？としていたパラメータに値を設定 1つ目の?にidの値をint型として設定
            productList = selectproductExecute(); // SQLの実行
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return  productList;
    }
        public int dbUpdateMemberTele(String name, String tele){
        String sql ="UPDATE PRODUCT " +
                " SET TELE = ? " +
                " WHERE NAME = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, tele);
            ps.setString(2, name);
            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
     public int dbUpdateProducrNameId(String name, String number){
        String sql ="UPDATE PRODUCT " +
                " SET NUMBER = ? " +
                " WHERE NAME = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, number);
            ps.setString(2, name);

            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }
          public int dbUpdateProducrName(String number, String name){
        String sql ="UPDATE PRODUCT " +
                " SET NAME = ? " +
                " WHERE NUMBER = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, number);

            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }   
        
     public int dbUpdateProductPrice(String number, int price){
        String sql ="UPDATE PRODUCT " +
                " SET PRICE = ? " +
                " WHERE NUMBER = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, price);
            ps.setString(2, number);

            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }           
    public int dbUpdateProductNamePrice(String name, int price){
        String sql ="UPDATE PRODUCT " +
                " SET PRICE = ? " +
                " WHERE NAME = ? ";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, price);
            ps.setString(2, name);

            return ps.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            return -1;
        }
    }    

            
    
}
