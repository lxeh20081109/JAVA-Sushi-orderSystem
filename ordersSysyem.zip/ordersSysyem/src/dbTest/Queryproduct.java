/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.product;
import java.util.List;

/**
 *
 * @author user
 */
public class Queryproduct {
    public static void main(String[] args){
        List<product> products;
        productDAO producttDAO = new productDAO();
        products = producttDAO.dbSearchproductAll();
        for(product pr: products){
            pr.println();
        }
    }
}
