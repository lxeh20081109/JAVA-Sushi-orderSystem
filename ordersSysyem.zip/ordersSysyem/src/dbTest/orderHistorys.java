/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.product;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 17jz0143
 */
public class orderHistorys {
        private String id;
        private String name;
        private Date time;
        private Integer count;
       
        
        public orderHistorys(Date time,String id,String name,Integer count){
            this.time = time;
            this.id = id;
            this.name = name;
            this.count = count;
        }
        public orderHistorys(){
            this(Date.valueOf("2018-10-01"),"","",0);
        }
        public void print(){
            System.out.print(this);
        }
        public String toString(){
            return getTime() + "\t" +"\t" +  getId() + "\t" + getName() + "\t" + getCount();
        }
        public void println(){
            print();
            System.out.println("");

        }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Date getTime() {
        return time;
    }

    public Integer getCount() {
        return count;
    }
        public static void main(String[] args){
            List<orderHistorys> orderList = new ArrayList<>();
            orderList.add(new orderHistorys(Date.valueOf("2018-11-11"),"105","リソウ",1200 * 12 ));

            for(orderHistorys or: orderList){
                System.out.println(or);
            }
        }
}
