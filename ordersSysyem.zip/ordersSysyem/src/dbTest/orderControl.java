/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.main_0;
import desing.main_2;
import desing.orderBoundary;
import desing.orderDetailBoundary;
import desing.orderdate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class orderControl {
    order prod;
    private orderDetailBoundary order22 ;
    private orderBoundary oboudary;
    private orderdate oDate;
    private List<order> orr;
    private main_0 m0;
    private main_2 m1;
    String datestring;
    String datestrings;
    private int row;
    private int colum;
    private int i;
    private String nad;
    private String nadd;
    public orderControl(){
        prod = new order();
        order22  = new orderDetailBoundary();
        oboudary = new orderBoundary();
        oDate = new orderdate();

    }

    public void orderadd(List<order> orr) {
        this.orr = orr;
        showorderadd();

    }
    public void showorderadd(){
        for(order or : orr){
            String[] rowData = or.toString().split(",", 5);
            order22.addTable(rowData);
        }
    }
    public void cal(){
//        new orderdate().setVisible(true);
        oDate.setControl(this);
        oDate.setVisible(true);
    }
    public void showData(){
        //new orderDetailBoundary().setVisible(true);
        order22.setVisible(true);
        
    }
    public static void main(String args[]){
        orderControl or = new orderControl();
        or.start();
    }

    private void start() {
        m0.setControl(this);
        m0.setVisible(true);
    }

    public void addtext(String datestring,String datestrings) {
        
       this.datestring = datestring;
       this.datestrings = datestrings;
       order22.addtext(datestring,datestrings);
    }
/*
    public void count(int row, int colum) {
        this.row = row;
        this.colum = colum;
        order22.countt(row,colum);
    }
*/

    public void list(int i) {
        this.i = i;
        System.out.print(i);
        order22.showcount(i);
        order22.showcount1(i);
    }

    public void addtext1(String nad,String nadd) {
        this.nad = nad;
        this.nadd = nadd;
        System.out.print("1111111111111");
        order22.addtext1(nad,nadd);
    }

    public void addhistory(long round) {
        System.out.print("");
    }




}
