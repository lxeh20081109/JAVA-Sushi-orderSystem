/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author user
 */
public class Member {
    private    Integer id;
    private    Date entryDate;
    private    String name;
    private    String tele;
    private    String address;
    
    
    public Member(Integer id,String name,String tele,String address,Date entryDate){
        setId(id);
        setName(name);
        settele(tele);
        setaddress(address);
        setEntryDate(entryDate);
    }
    public Member(){
        this(0,"","","",Date.valueOf("2018-10-01"));
    }
    public String toString(){
        return "会員番号:  " +getId() + "\n    " + "名前 :" + getName() + "\n    "  + "電話番号 :" +gettele() + "\n    "  + "住所 :" + getaddress() +  "\n    "  + "入力日 :" + getentryDate() +
                "\n" + "=============================================";
    }
    public void print(){
        System.out.print(this);
    }
    public void setaddress(String address){
        this.address = address;
    }
    public String getaddress(){
        return address;
    }
    public void settele(String tele){
        this.tele = tele;
    }
    public String gettele(){
        return tele;
    }
    public void println(){
        print();
        System.out.print("");
    }
    public void setId(Integer id){
        this.id = id;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setEntryDate(Date entryDate){
        this.entryDate = entryDate;
    }
    public Integer getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public Date getentryDate(){
        return entryDate;
    }
    
    public static void main(String[] args){
        List<Member>members = new ArrayList<>();
        
    //    members.add(new Member(101,"鈴木",0902345,'東京都',Date.valueOf("2018-10-01")));
        
        for(Member member: members){
            System.out.println(member);
        }
    }
}
