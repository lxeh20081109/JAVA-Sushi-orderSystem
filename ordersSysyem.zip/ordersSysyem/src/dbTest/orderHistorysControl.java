/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.orderHistorysss;
import desing.productEntry;
import desing.productIDChange;
import desing.productNameChange;
import desing.productsee;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class orderHistorysControl {
    private orderHistorysss orderhistory;
    private String text;
    private String text0;
    private String text1;
    private Integer text2;
    private List<orderHistorys> orderList;
    
    
    
    public orderHistorysControl(){
        orderhistory = new orderHistorysss();
    }

    public void toData(List<orderHistorys> orderList) {
        this.orderList = orderList;
        showorderadd();
    }
    public void showorderadd(){
        for(orderHistorys or : orderList){
            String[] rowData = or.toString().split(",", 4);
            orderhistory .addTable(rowData);
        }
    }

}
