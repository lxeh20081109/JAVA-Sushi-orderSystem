/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import desing.productEntry;
import desing.product;
import desing.productIDChange;
import desing.productNameChange;
import desing.productsee;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class Controlproduct {
    private productsee entry;
    private List<product> productList;
    private productDAO productDAO;
    private productEntry etry;
    private String productID;
    private productIDChange productidchange;
    private String text;
    private productNameChange productnamechange;
    
    public Controlproduct(){
        entry = new productsee();
        productList = new ArrayList<>();
        etry = new productEntry();
        productidchange = new productIDChange();
        productnamechange = new productNameChange();
    }
    public void start(){
        entry.setControl(this);
        entry.setVisible(true);
        
    }

    public static void mian(String[] args){
        new Controlproduct().start();
    }

    public void showproductAll() {
        productList = productDAO.dbSearchproductAll();
        entry.showProductTextArea(productList);
    }



    public void insert(String number, String name, Integer price) {

        
        try{
            productDAO productDAO = new productDAO(); 
            product pro = new product(number,name,price);
            if(productDAO.dbInsertproduct(pro) > 0){
               etry.showInfomationMessage("登録しました");
               etry.initTextFieldAll();
            }           
            else {
                etry.showErrMessage("商品番号が登録済みです");
                etry.selectTextFieldID();
            }
        }
        catch (NumberFormatException e) {
            etry.showErrMessage("単価は数値で入力してください");
            etry.selectTextFieldID();
        }
    

    }

    public void toId(String parseInt) {
       this.productID = parseInt;
       productidchange.toID(productID);
    }

    public void showIdChange() {
       productidchange.setVisible(true);
    }

    public void toName(String text) {
        this.text = text;
        productnamechange.toID(text);
    }

    public void showNameChange() {
       productnamechange.setVisible(true);
    }
    
}
