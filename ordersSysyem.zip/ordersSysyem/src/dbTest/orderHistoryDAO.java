/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLDataException;
import java.sql.SQLIntegrityConstraintViolationException;
/**
 *
 * @author user
 */
public class orderHistoryDAO {
        
    private static Connection  con;  
    private  static PreparedStatement ps;
    
     public orderHistoryDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con                = dbManager.getConnection();
     }
     public List<orderHistorys>selectMemberExecute(){
        List<orderHistorys>orderList = new ArrayList();
        try{
            orderList.clear();
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                orderHistorys orderhistorys = new orderHistorys();
                setorderHistorys(orderhistorys,rs);
                orderList.add(orderhistorys);
            }
            rs.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return orderList;
    }    

    public void setorderHistorys(orderHistorys orderhistorys, ResultSet rs) {
        try{
            Date time = rs.getDate("TIME");
            String id = rs.getString("ID");
            String name = rs.getString("NAME");                              
            Integer count = rs.getInt("COUNT");
            orderhistorys.setId(id);
            orderhistorys.setName(name);
            orderhistorys.setTime(time);
            orderhistorys.setCount(count);
            
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
        public List<orderHistorys>dbSearchOrderHistorysAll(){
        List<orderHistorys>orderList = new ArrayList();
        String sql ="SELECT *" + 
                "FROM ORDERHISTORYS ";
        try{
            ps = con.prepareStatement(sql);
            orderList = selectMemberExecute();
        }        
        catch(SQLException e){
            e.printStackTrace();
        }
        return orderList;
    }
    public int dbInsertOrderHistorys(orderHistorys orderhistorys){
        String sql ="INSERT INTO ORDERHISTORYS" +
                " values(?, ?, ?, ?) ";
        try{
            ps = con.prepareStatement(sql);
            ps.setDate(1, orderhistorys.getTime());
            ps.setString(2, orderhistorys.getId());          
            ps.setString(3, orderhistorys.getName());
            ps.setInt(4, orderhistorys.getCount());
            
            
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;   // 挿入できなかったので挿入件数0を返す
        }
        catch (SQLException e) {    
           e.printStackTrace();
           return -1;
        }
    }

    
}
