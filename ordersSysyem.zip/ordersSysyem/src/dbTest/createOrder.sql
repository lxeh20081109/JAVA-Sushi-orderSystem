/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  17jz0143
 * Created: 2019/02/06
 */


CREATE TABLE ORDERRS(
TIME DATE,
ID VARCHAR(10),
NAME VARCHAR(10),
COUNT INTEGER NOT NULL
);
