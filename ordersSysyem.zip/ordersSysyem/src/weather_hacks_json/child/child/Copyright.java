package weather_hacks_json.child.child;

import weather_hacks_json.child.child.child.CopyrightImage;

public class Copyright {

    Provider[] provider;
    String link;
    String title;
    CopyrightImage image;

}
