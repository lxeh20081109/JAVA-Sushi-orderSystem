package weather_hacks_json.child.child;

public class Image {

    int width;
    String url;
    String title;
    int height;

}
