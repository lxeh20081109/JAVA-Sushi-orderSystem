package weather_hacks_json.child.child;

public class Provider {

    String link;
    String name;

}
