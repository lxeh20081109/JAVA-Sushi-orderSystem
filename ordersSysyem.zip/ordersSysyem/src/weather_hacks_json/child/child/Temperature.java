package weather_hacks_json.child.child;

import weather_hacks_json.child.child.child.Max;
import weather_hacks_json.child.child.child.Min;

public class Temperature {

    public Min min;
    public Max max;

}
