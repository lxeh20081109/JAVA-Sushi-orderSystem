package weather_hacks_json.child.child.child;

public class CopyrightImage {

    int width;
    String link;
    String url;
    String title;
    int height;

}
