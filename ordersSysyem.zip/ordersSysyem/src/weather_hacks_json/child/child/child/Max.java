package weather_hacks_json.child.child.child;

public class Max {
    public String celsius;
    public String fahrenheit;
}
