package weather_hacks_json.child.child.child;

public class Min {
    public String celsius;
    public String fahrenheit;
}
