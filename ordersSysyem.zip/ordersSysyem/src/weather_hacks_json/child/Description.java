package weather_hacks_json.child;

public class Description {

   // public String publicTime;
    public String text;
    

}
