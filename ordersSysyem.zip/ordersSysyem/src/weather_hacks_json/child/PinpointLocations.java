package weather_hacks_json.child;

public class PinpointLocations {

    String link;
    String name;

}
