package weather_hacks_json.child;

import weather_hacks_json.child.child.Image;
import weather_hacks_json.child.child.Temperature;

public class Forecasts {

    String dateLabel;
    String telop;
    String date;
    Temperature temperature;
    Image image;

}
