package weather_hacks_json.child;

public class Location {

    String city;
    String area;
    String prefecture;

}
