/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  user
 * Created: 2019/02/21
 */
DELETE FROM ORDERHISTORYS;
INSERT INTO ORDERHISTORYS (TIME,"ID","NAME",COUNT) VALUES('2019-2-20','105','りそう',4300);