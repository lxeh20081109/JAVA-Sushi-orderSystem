/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  user
 * Created: 2019/01/20
 */

CREATE TABLE PRODUCT(
NUMBER VARCHAR(10) NOT NULL,
NAME VARCHAR(10),
PRICE INTEGER NOT NULL
);
ALTER TABLE PRODUCT ADD CONSTRAINT PK_PRODUCT PRIMARY KEY(NUMBER);
