/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  user
 * Created: 2018/12/23
 */
CREATE TABLE MEMBER(
ID INTEGER NOT NULL,
NAME VARCHAR(10),
TELE VARCHAR(20),
ADDRESS VARCHAR(20),
ENTRY_DATE DATE
);
ALTER TABLE MEMBER ADD CONSTRAINT PK_MEMBER PRIMARY KEY(ID);
