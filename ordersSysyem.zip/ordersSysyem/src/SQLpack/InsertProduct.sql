/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  user
 * Created: 2019/01/20
 */
/*
        mac
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('641','舞（まい）1~5人前',1300);

DELETE FROM PRODUCT;
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('A641','舞',1500);
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('A636','躍',1300);
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('M101','海鮮恵方巻',740);
*/

/*     windos 
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES(641,'舞（まい）1~5人前',1300);

*/

DELETE FROM PRODUCT;
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('641','舞',1500);
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('636','躍',1300);
INSERT INTO PRODUCT("NUMBER","NAME",PRICE) VALUES('101','海鮮恵方巻',740);