/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  user
 * Created: 2019/01/24
 */
/*

INSERT INTO USER01.MEMBER (ID, "NAME", ADDRESS, TELE, ENTRY_DATE) 
	VALUES (101, '青木', '埼玉県', 90456789, '2019-01-24');

*/
DELETE FROM MEMBER;
INSERT INTO USER01.MEMBER (ID, "NAME", ADDRESS, TELE, ENTRY_DATE) 
	VALUES (101, '青木', '埼玉県', '1234789', '2019-01-24');
INSERT INTO USER01.MEMBER (ID, "NAME", ADDRESS, TELE, ENTRY_DATE) 
	VALUES (102, '田中', '東京都', '9156789', '2019-01-25');
INSERT INTO USER01.MEMBER (ID, "NAME", ADDRESS, TELE, ENTRY_DATE) 
	VALUES (103, '渡辺', '新宿区', '1268048', '2019-01-26');
INSERT INTO USER01.MEMBER (ID, "NAME", ADDRESS, TELE, ENTRY_DATE) 
	VALUES (104, '阿部', '日暮里', '0981472', '2019-01-27');
INSERT INTO USER01.MEMBER (ID, "NAME", ADDRESS, TELE, ENTRY_DATE) 
	VALUES (105, 'りそう', '埼玉県', '3791649', '2019-01-28');